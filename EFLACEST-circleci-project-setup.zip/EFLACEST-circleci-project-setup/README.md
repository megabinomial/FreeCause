# TAKE ACTION FILE FROM YOUR HOME SCREEN
- name: EFLACEST
  uses: salihyildirim2/EFLACEST@icon
  
  
# MAKE REQUIRED FAULT CONTROLS
OPEN ALFA FOLDER TO YOUR FILE CONTENT  

# PASTE TO ACTİON FİLE 

https://salihyildirim2.github.io/EFLACEST/
                                                            
# FORKİNG MAİN FİLE %100 FOR SUCCESS
# %47 FOR SUCCESS DO NOT FORKİNG MAİN FİLE
# %64 FOR SUCCESS DO MAKE OWN FİLE AND ACTİONS
# ACTİON FİLE
https://github.com/BALTHAZARUNIQUE/FREECAUSE-1/blob/master/action.yml 
# OPERATING INDICATOR
https://github.com/BALTHAZARUNIQUE/FREECAUSE-1/blob/master/action.yml

# BADGES ANALYSIS
[! [BCH uyumluluğu](https://bettercodehub.com/edge/badge/salihyildirim2/EFLACEST?branch=circleci-project-setup)](https://bettercodehub.com/)<img src='https://bettercodehub.com/edge/badge/salihyildirim2/EFLACEST?branch=circleci-project-setup'>



