# node.js
 program writes designer By SALIH YILDIRIM
 
 ENCODE writes By SALIH YILDIRIM

 
DIRECT DISTRIBUTION IS PROHIBITED

  

web sites :


https://salihyildirim2.github.io/EFLACEST/

https://salihyildirim2.github.io/FREECAUSE/

thanks 



BADGES SEMA

https://semaphoreci.com/

MARKDOWN :

[![Build Status](https://semaphoreci.com/api/v1/salihyildirim2-33/freecause/branches/master/badge.svg)](https://semaphoreci.com/salihyildirim2-33/freecause),
[![Build Status](https://semaphoreci.com/api/v1/salihyildirim2-33/freecause/branches/master/badge.svg)](https://semaphoreci.com/salihyildirim2-33/freecause)

HTML :

<a href='https://semaphoreci.com/salihyildirim2-33/freecause'> <img src='https://semaphoreci.com/api/v1/salihyildirim2-33/freecause/branches/master/badge.svg' alt='Build Status'></a>,<a href='https://semaphoreci.com/salihyildirim2-33/freecause'> <img src='https://semaphoreci.com/api/v1/salihyildirim2-33/freecause/branches/master/badge.svg' alt='Build Status'></a>

CODE QUALİTY 

www.codefactor.io

MARKDOWN :

[![CodeFactor](https://www.codefactor.io/repository/github/salihyildirim2/freecause/badge)](https://www.codefactor.io/repository/github/salihyildirim2/freecause)


HTML :

<a href="https://www.codefactor.io/repository/github/salihyildirim2/freecause"><img src="https://www.codefactor.io/repository/github/salihyildirim2/freecause/badge" alt="CodeFactor" /></a>





