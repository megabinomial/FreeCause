# TAKE ACTION FILE FROM YOUR HOME SCREEN
- name: EFLACEST
  uses: salihyildirim2/EFLACEST@icon
  
  
# MAKE REQUIRED FAULT CONTROLS
OPEN ALFA FOLDER TO YOUR FILE CONTENT  

# PASTE TO ACTİON FİLE 
https://github.com/salihyildirim2/FREECAUSE
                                                            
# FORKİNG MAİN FİLE %100 FOR SUCCESS
# %47 FOR SUCCESS DO NOT FORKİNG MAİN FİLE
# %64 FOR SUCCESS DO MAKE OWN FİLE AND ACTİONS
# ACTİON FİLE
https://github.com/BALTHAZARUNIQUE/FREECAUSE-1/blob/master/action.yml 
# OPERATING INDICATOR
https://github.com/BALTHAZARUNIQUE/FREECAUSE-1/blob/master/action.yml


# CODE BADGES ANALYSIS
[![BCH compliance](https://bettercodehub.com/edge/badge/salihyildirim2/FREECAUSE?branch=master)](https://bettercodehub.com/)<img src='https://bettercodehub.com/edge/badge/salihyildirim2/FREECAUSE?branch=master'>
