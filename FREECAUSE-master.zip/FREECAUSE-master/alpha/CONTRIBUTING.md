1  ACCELERATION OF APP GATEWAYS ,
2  automatic coordination ,
3  compact operating system possibility ,
4  cleaner concealer guard ,
5  fluidity of colors 
