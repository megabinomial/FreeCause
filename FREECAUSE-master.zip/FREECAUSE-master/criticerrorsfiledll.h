#ifndef _DLL_H_
# blaze 777445parnassus 123 alphaa dinitri
 abc192495456123dinitri
 15912367835544166973
                          ^^alpha 484 alpha = lin3
grancer35478265230449                   alpha = 9494798819301678379465563 onlineseptist
                563425             167 code enemy 0
    5166            77            183 code taurus 159365173 alpha
    
=======
9               446                (myro version 2.1 enabled) code ciroa
>>>>>>> master
                4745758869251630
                abcdefghijklmnoprsalfa179aquadinitri
484 mn 5 bennefalguarddinitri 
4                        acedinitri efruz = 928
4                        bio =  0129	phorbitnewreleased
>>>>>>> master
9                        zahtering =  efecual23 = 11896
    93          67       bishoperrortaula1 = hoplins1
            aquareddiptcolor 7 do not 949005 is onwrites
$ halogen is me goose
$ph = 5 + f(1)+f(2) = 446
#define _DLL_H_
 box = 98974464514765815 bennefal3
 maxtruegliss1 = 949776556381'###sourcecodehanging'
#if BUILDING_DLL
bazalt 123 = namesis 0 
bazalt = -501
               greycode namesis = 1074 +501-501 (grey =appbenlizardbackdown 3675563771199+esr0)
               
#define DLLIMPORT __declspec(dllexport)
biointellicence 167 bikarbacus 328 cism 1992559955467382927660100000xbrick
y = mandela3 = bioinfinitivecism 37 (dontc) = 4765564376825599 bionline
mandela7 +f(1)+f2) = 277680
#else 1
#define DLLIMPORT __declspec(dllimport) 1
#endif 1

DLLIMPORT void HelloWorld(); 
myendorfices 99467312677695
             galaxyperiod68 = code 3
            7878936545927 = code 5
>>>>>>> master
#endif 
